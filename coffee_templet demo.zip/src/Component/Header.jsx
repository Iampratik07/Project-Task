import React from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify';


export default function Header() {
    const redirect = useNavigate();
    const logout = () => {

        localStorage.removeItem('id');
        localStorage.removeItem('name');
        toast.success('Logout Success !');
        redirect('/');
    }
    return (
        <div>
            {/* Navbar Start */}
            <div className="container-fluid p-0 nav-bar">
                <nav className="navbar navbar-expand-lg bg-none navbar-dark py-3">
                    <a href="index.html" className="navbar-brand px-lg-4 m-0">
                        <h1 className="m-0 display-4 text-uppercase text-white">KOPPEE</h1>
                    </a>

                   
                    <button type="button" className="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                        <span className="navbar-toggler-icon" />
                    </button>
                    <div className="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                        <div className="navbar-nav ml-auto p-4">
                            <NavLink to="/" className="nav-item nav-link active">Home</NavLink>
                            <NavLink to="/About" className="nav-item nav-link">About</NavLink>
                            <NavLink to="/Service" className="nav-item nav-link">Service</NavLink>
                            <NavLink to="/Menu" className="nav-item nav-link">Menu</NavLink>
                            <NavLink to="/Login" className="nav-item nav-link">Login</NavLink>
                            
                           
                            <NavLink to="/Contact" className="nav-item nav-link">Contact</NavLink>

                            {
                                (() => {
                                    if (localStorage.getItem('id')) {

                                        return (<li className="nav-item">
                                            <NavLink className="nav-link" to="javascript:void(0)" onClick={logout}>Logout</NavLink>
                                        </li>)
                                    }
                                })()}
                
                        </div>
                    </div>
                </nav>
            </div>
            {/* Navbar End */}
           
        </div>



    )
}
