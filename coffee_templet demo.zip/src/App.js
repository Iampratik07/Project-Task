import {BrowserRouter, Routes, Route} from "react-router-dom";

import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import Header from "./Component/Header";
import Footer from "./Component/Footer";

import About from "./Pages/About";
import Contact from "./Pages/Contact";
import Home from "./Pages/Home";
import Menu from "./Pages/Menu";
import Service from "./Pages/Service";
import Login from "./Pages/Login";
import Signup from './Pages/Signup';
import Myaccount from "./Pages/Myaccount";
import Edit_profile from "./Pages/Edit_profile";
import PNF from './Pages/PNF';



function App() {
  return (
    <BrowserRouter>
    <ToastContainer/>
      <Routes>
        <Route path="/" index element={<><Header /><Home /><Footer/></>}></Route>
        <Route path="/Home" index element={<><Header /><Home /><Footer/></>}></Route>
        <Route path="/About" index element={<><Header /><About /><Footer/></>}></Route>
        <Route path="/Contact" index element={<><Header /><Contact /><Footer/></>}></Route>
        <Route path="/Menu" index element={<><Header /><Menu /><Footer/></>}></Route>
        <Route path="/Service" index element={<><Header /><Service /><Footer/></>}></Route>
        <Route path="/Login" index element={<><Header /><Login /><Footer/></>}></Route>
        <Route path="signup" index element={<> <Header/> <Signup/> <Footer/> </>}></Route>
        <Route path="profile" index element={<> <Header/> <Myaccount/> <Footer/> </>}></Route>
        <Route path="editprofile/:id" index element={<> <Header/> <Edit_profile/> <Footer/> </>}></Route>
        <Route path="*" index element={<> <Header/> <PNF/> <Footer/> </>}></Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
