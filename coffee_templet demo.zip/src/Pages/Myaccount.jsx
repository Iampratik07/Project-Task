import React,{useState,useEffect} from 'react'
import axios from 'axios';
import {Link, useNavigate} from 'react-router-dom'


export default function Myaccount() {
  const redirect=useNavigate();
  useEffect(()=>{
    if(!(localStorage.getItem('id')))
    {
      redirect('/');
    }
    fetch();
  },[]);

  const [data,setData]=useState({});
  const fetch=async()=>{
    const res=await axios.get(`http://localhost:3000/user/${localStorage.getItem('id')}`);
    setData(res.data);
  }

  
    
  return (
    <div>
  {/* Start Content Page */}
  <div className="container-fluid bg-light py-5">
        <div className="col-md-6 m-auto text-center">
          <h1 className="h1">Edit Profile</h1>
          <p>
            Edit Profile
          </p>
        </div>
      </div>
       {/* Start Content Page */}
       <div className="container py-5">
        <div className="row py-5">
          <table class="table table-striped">
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Mobile</th>
                <th>Action</th>
              </tr>
            </thead>
            
            <tbody>
              <tr>
                <td>{data.id}</td>
                <td>{data.name}</td>
                <td>{data.email}</td>
                <td>{data.mobile}</td>
                <td><button onClick={()=>{ redirect('/editprofile/'+data.id)}}>Edit</button></td>
              </tr>
            </tbody>
          </table>
        </div>
       </div>
        {/* End Content Page */}
    </div>
  )
}


