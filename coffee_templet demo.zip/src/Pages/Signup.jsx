import React, { useState } from 'react'
import { NavLink } from 'react-router-dom'
import axios from 'axios'

import { toast } from 'react-toastify';

export default function Signup() {

  const [formvalue, setFormvalue] = useState({
    id: "",
    name: "",
    email: "",
    password: "",
    mobile: "",
    status: ""
  })

  const onchange = (e) => {
    setFormvalue({ ...formvalue, id: new Date().getTime().toString(), status: "Unblock", [e.target.name]: e.target.value });
    //console.log(formvalue);
  }

  const validation = () => {
    let result = true;
    if (formvalue.name == "" || formvalue.name == null) {
      result = false;
      toast.error('Name field is required !');
      return false;
    }
    if (formvalue.email == "" || formvalue.email == null) {
      result = false;
      toast.error('email field is required !');
      return false;
    }
    if (formvalue.password == "" || formvalue.password == null) {
      result = false;
      toast.error('password field is required !');
      return false;
    }
    if (formvalue.mobile == "" || formvalue.mobile == null) {
      result = false;
      toast.error('mobile field is required !');
      return false;
    }
    return result;
  }




  const onsubmit = async (e) => {
    e.preventDefault();
    if (validation()) {
      await axios.post(`http://localhost:3000/user`, formvalue)
        .then((res) => {
          //console.log(res);
          if(res.status===201)
          {
            toast.success('Registeration Success');
            setFormvalue({ ...formvalue, name: "", email: "", password: "", mobile: "" });
          }
        })
    }
  }
  return (
    <div>
     {/* Page Header Start */}
     <div className="container-fluid page-header mb-5 position-relative overlay-bottom">
        <div className="d-flex flex-column align-items-center justify-content-center pt-0 pt-lg-5" style={{ minHeight: 400 }}>
          <h1 className="display-4 mb-3 mt-0 mt-lg-5 text-white text-uppercase">Sign Up</h1>
          <div className="d-inline-flex mb-lg-5">
            <p className="m-0 text-white"><NavLink className="text-white" href>Home</NavLink></p>
            <p className="m-0 text-white px-2">/</p>
            <p className="m-0 text-white">Sign Up</p>
          </div>
        </div>
      </div>
      {/* Page Header End */}
     
      {/* Start Contact */}
      <div className="container py-5">
        <div className="row py-5">
          <form className="col-md-9 m-auto" method="post" role="form">
            <div className="row">
            <div className="form-group col-md-6 mb-3">
                <label htmlFor="inputname">Name</label>
                <input type="text" value={formvalue.name} onChange={onchange} className="form-control mt-1" id="name" name="name" placeholder="Name" />
              </div>
              <div className="form-group col-md-6 mb-3">
                <label htmlFor="inputemail">Email</label>
                <input type="email" value={formvalue.email} onChange={onchange} className="form-control mt-1" id="email" name="email" placeholder="Email" />
              </div>
            </div>
            <div className="form-group col-md-6 mb-3">
              <label htmlFor="inputsubject">Password</label>
              <input type="password" value={formvalue.password} onChange={onchange} className="form-control mt-1" id="password" name="password" placeholder="Password" />
            </div>
            <div className="form-group col-md-6 mb-3">
                <label htmlFor="inputemail">Mobile</label>
                <input type="number" value={formvalue.mobile} onChange={onchange} className="form-control mt-1" id="email" name="mobile" placeholder="Mobile" />
              </div>
            <div className="row">
            <div className="col text-start mt-2">
                <button type="submit" onClick={onsubmit} className="btn btn-success btn-lg px-3">Signup</button>
              </div>
              <div className="col text-end mt-2">
                <NavLink to="/login" >Click Here for Login</NavLink>
              </div>
            </div>
          </form>
        </div>
      </div>
      {/* End Contact */}
    </div>

  )
}
