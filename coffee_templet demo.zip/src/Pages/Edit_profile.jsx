import React, { useState,useEffect } from 'react'
import { redirect,   useParams, useNavigate } from 'react-router-dom'
import axios from 'axios'
import { toast }  from 'react-toastify';

export default function Edit_profile() {

  const redirect=useNavigate();
  const [formvalue, setFormvalue] = useState({
    name:"",
    email:"",
    password:"",
    mobile:"",
  })

  const {id}=useParams();
  useEffect(()=>{
    if(!(localStorage.getItem('id')))
    {
      redirect('/');
    }
    fetch();
  },[]);

  const fetch=async()=>{
    const res=await axios.get(`http://localhost:3000/user/${id}`);
    console.log(res.data);
    setFormvalue({...formvalue,name:res.data.name,email:res.data.email,password:res.data.password,mobile:res.data.mobile});
  }

  const onchange = (e) => {
    setFormvalue({ ...formvalue,[e.target.name]: e.target.value });
  }

  const validation = () => {
    let result = true;
    if (formvalue.name == "" || formvalue.name == null) {
      result = false;
      toast.error('Name field is required !');
      return false;
    }
    if (formvalue.email == "" || formvalue.email == null) {
      result = false;
      toast.error('email field is required !');
      return false;
    }
    if (formvalue.password == "" || formvalue.password == null) {
      result = false;
      toast.error('password field is required !');
      return false;
    }
    if (formvalue.mobile == "" || formvalue.mobile == null) {
      result = false;
      toast.error('mobile field is required !');
      return false;
    }
    return result;
    
  }
  return (
    <div>
       {/* Start Content Page */}
     <div className="container-fluid bg-light py-5">
        <div className="col-md-6 m-auto text-center">
          <h1 className="h1">Edit Profile</h1>
         
        </div>
      </div>
       {/* End Content Page */}
     
      {/* Start Contact */}
      <div className="container py-5">
        <div className="row py-5">
          <form className="col-md-9 m-auto" method="post" role="form">
            <div className="row">
            <div className="form-group col-md-6 mb-3">
                <label htmlFor="inputname">Name</label>
                <input type="text" value={formvalue.name} onChange={onchange} className="form-control mt-1" id="name" name="name" placeholder="Name" />
              </div>
              <div className="form-group col-md-6 mb-3">
                <label htmlFor="inputemail">Email</label>
                <input type="email" value={formvalue.email} onChange={onchange} className="form-control mt-1" id="email" name="email" placeholder="Email" />
              </div>
            </div>
            <div className="form-group col-md-6 mb-3">
              <label htmlFor="inputsubject">Password</label>
              <input type="password" value={formvalue.password} onChange={onchange} className="form-control mt-1" id="name" name="password" placeholder="Password" />
            </div>
            <div className="form-group col-md-6 mb-3">
                <label htmlFor="inputemail">Mobile</label>
                <input type="number" value={formvalue.mobile} onChange={onchange} className="form-control mt-1" id="email" name="mobile" placeholder="Mobile" />
              </div>
            <div className="row">
            <div className="col text-start mt-2">
                <button type="submit" onClick={onsubmit} className="btn btn-success btn-lg px-3">Save</button>
              </div>
            </div>
          </form>
        </div>
      </div>
      {/* End Contact */}
    </div>
  )
}
