import React, { useState } from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import axios from 'axios'
import { toast } from 'react-toastify';

export default function Login() {

  const redirect = useNavigate();
  const [formvalue, setFormvalue] = useState({
    email: "",
    password: "",
  })

  const onchange = (e) => {
    setFormvalue({ ...formvalue, [e.target.name]: e.target.value });
  }

  const validation = () => {
    let result = true;
    if (formvalue.email == "" || formvalue.email == null) {
      result = false;
      toast.error('email field is required !');
      return false;
    }
    if (formvalue.password == "" || formvalue.password == null) {
      result = false;
      toast.error('password field is required !');
      return false;
    }
    return result;
  }

  const onsubmit = async (e) => {
    e.preventDefault();
    if (validation()) {
      await axios.get(`http://localhost:3000/user?email=${formvalue.email}`)
        .then((res) => {
          if (res.data.length > 0) {
            if (res.data[0].password == formvalue.password) {
              //session storage variable
              localStorage.setItem('id', res.data[0].id);
              localStorage.setItem('name', res.data[0].name);

              toast.success('Login Successfull !');
              return redirect('/');
            }
            else {
              toast.error(' Password not match !');
              return false;
            }
          }
          else {
            toast.error(' Email not match !');
            return false;
          }
        })
    }
  }
  return (
    <div>
      {/* Page Header Start */}
      <div className="container-fluid page-header mb-5 position-relative overlay-bottom">
        <div className="d-flex flex-column align-items-center justify-content-center pt-0 pt-lg-5" style={{ minHeight: 400 }}>
          <h1 className="display-4 mb-3 mt-0 mt-lg-5 text-white text-uppercase">Login</h1>
          <div className="d-inline-flex mb-lg-5">
            <p className="m-0 text-white"><NavLink className="text-white" href>Home</NavLink></p>
            <p className="m-0 text-white px-2">/</p>
            <p className="m-0 text-white">Login</p>
          </div>
        </div>
      </div>
      {/* Page Header End */}
      {/* Start Contact */}
      <div className="container py-5">
        <div className="row py-5">
          <form className="col-md-9 m-auto" method="post" role="form">
            <div className="row">

              <div className="form-group col-md-12 mb-3">
                <label htmlFor="inputemail">Email</label>
                <input type="email" value={formvalue.email} onChange={onchange} className="form-control mt-1" id="email" name="email" placeholder="Email" />
              </div>
            </div>
            <div className="form-group col-md-12 mb-3">
              <label htmlFor="inputsubject">Password</label>
              <input type="Password" value={formvalue.password} onChange={onchange} className="form-control mt-1"   id="name" name="password" placeholder="Password" />
            </div>

            <div className="row">
              <div className="col text-start mt-2">
                <button type="submit" onClick={onsubmit} className="btn btn-success btn-lg px-3">Login</button>
              </div>
              <div className="col text-end mt-2">
                <NavLink to="/signup" >Click Here for Signup</NavLink>
              </div>
            </div>
          </form>
        </div>
      </div>
      {/* End Contact */}
    </div>

  )
}
