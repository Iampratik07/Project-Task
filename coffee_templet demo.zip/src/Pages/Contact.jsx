import React, { useState } from 'react'
import axios from 'axios'
import { toast } from 'react-toastify';
import { NavLink } from 'react-router-dom';


export default function Contact() {
  const [formvalue, setFormvalue] = useState({
    id: "",
    name: "",
    email: "",
    subject: "",
    message: "",
  })

  const onchange = (e) => {
    setFormvalue({ ...formvalue, id: new Date().getTime().toString(), [e.target.name]: e.target.value });
    //console.log(formvalue);
  }

  const validation = () => {
    let result = true;
    if (formvalue.name == "" || formvalue.name == null) {
      result = false;
      toast.error('Name field is required !');
      return false;
    }
    if (formvalue.email == "" || formvalue.email == null) {
      result = false;
      toast.error('email field is required !');
      return false;
    }
    if (formvalue.subject == "" || formvalue.subject == null) {
      result = false;
      toast.error('subject field is required !');
      return false;
    }
    if (formvalue.message == "" || formvalue.message == null) {
      result = false;
      toast.error('message field is required !');
      return false;
    }
    return result;
  }




  const onsubmit = async (e) => {
    e.preventDefault();
    if (validation()) {
      await axios.post(`http://localhost:3000/contact`, formvalue)
        .then((res) => {
          //console.log(res);
          toast.success('Contact Success');
          setFormvalue({ ...formvalue, name: "", email: "", subject: "", message: "" });

        })
    }
  }
  return (
    <div>
      {/* Page Header Start */}
      <div className="container-fluid page-header mb-5 position-relative overlay-bottom">
        <div className="d-flex flex-column align-items-center justify-content-center pt-0 pt-lg-5" style={{ minHeight: 400 }}>
          <h1 className="display-4 mb-3 mt-0 mt-lg-5 text-white text-uppercase">Contact</h1>
          <div className="d-inline-flex mb-lg-5">
            <p className="m-0 text-white"><NavLink className="text-white" href>Home</NavLink></p>
            <p className="m-0 text-white px-2">/</p>
            <p className="m-0 text-white">Contact</p>
          </div>
        </div>
      </div>
      {/* Page Header End */}
      {/* Start Contact */}
      <div className="container py-5">
        <div className="row py-5">
          <form className="col-md-9 m-auto" method="post" role="form">
            <div className="row">
              <div className="form-group col-md-6 mb-3">
                <label htmlFor="inputname">Name</label>
                <input type="text"  value={formvalue.name} onChange={onchange} className="form-control mt-1" id="name" name="name" placeholder="Name" />
              </div>
              <div className="form-group col-md-6 mb-3">
                <label htmlFor="inputemail">Email</label>
                <input type="email"  value={formvalue.email} onChange={onchange} className="form-control mt-1" id="email" name="email" placeholder="Email" />
              </div>
            </div>
            <div className="mb-3">
              <label htmlFor="inputsubject">Subject</label>
              <input type="text"  value={formvalue.subject} onChange={onchange} className="form-control mt-1" id="subject" name="subject" placeholder="Subject" />
            </div>
            <div className="mb-3">
              <label htmlFor="inputmessage">Message</label>
              <textarea  onChange={onchange} className="form-control mt-1" id="message" name="message" placeholder="Message" rows={8}>{formvalue.message}</textarea>
            </div>
            <div className="row">
              <div className="col text-end mt-2">
                <button type="submit" onClick={onsubmit} className="btn btn-success btn-lg px-3">Let’s Talk</button>
              </div>
            </div>
          </form>
        </div>
      </div>
      {/* End Contact */}
    </div>


  )
}
