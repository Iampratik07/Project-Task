import React from 'react'

export default function PNF() {
  return (
    <div>
        {/* Start Content Page */}
      <div className="container-fluid bg-light py-5">
        <div className="col-md-6 m-auto text-center">
          <h1 className="h1">PNF</h1>
          <p>
            Page Not Found
          </p>
          <h1>404</h1>
        </div>
      </div>
     
   
      {/* End Contact */}
    </div>
  )
}
